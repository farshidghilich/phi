module.exports = {
  service: {
    name: 'space-explorer',
  },
};
