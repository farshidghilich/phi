package xyz.lrhm.phiapp.ui.splashScreen

import androidx.lifecycle.ViewModel

class SplashViewModel : ViewModel() {
    // TODO: Implement the ViewModel


}